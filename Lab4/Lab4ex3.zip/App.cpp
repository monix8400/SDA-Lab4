#include <iostream>
#include "PriorityQueue.h"
#include "TestP3.h"


using namespace std;




int main() {
	testP3();

	cout << "End <3" << endl;
	system("pause");

}
